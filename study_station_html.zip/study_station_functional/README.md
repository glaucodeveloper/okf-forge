# Study Station — protótipo funcional

Esta versão implementa as telas como uma aplicação HTML/CSS/JS funcional, usando a mesma estrutura de domínio planejada para o consumer GlaucoPlastic.

## Persistência

- `localStorage`: persiste todo o domínio com a chave `studyStation.v3`.
- `BroadcastChannel`: sincroniza alterações entre janelas/abas quando disponível.
- fallback em memória: mantém a aplicação funcional em previews que bloqueiam `localStorage`.
- `Configurações`: exporta/importa o banco completo em JSON.

Tabelas lógicas persistidas:

`accounts`, `subjects`, `topics`, `topicRelations`, `topicDocuments`, `topicDocumentVersions`, `topicChatThreads`, `topicChatMessages`, `topicDocumentSuggestions`, `students`, `enrollments`, `studentMemoryProfiles`, `studentTopicProgress`, `studentTopicProgressSamples`, `activities`, `questionnaires`, `questions`, `answers`, `activityEvents`, `studyAccessTokens`, `clientPresence`, `reportDefinitions`, `reportRuns`, `reportInsights`.

## Matérias / tópico

`materia-topico.html`

Abas implementadas:
- Dashboard
- Conhecimento (OKF)
- Estrutura
- Relações
- Atividades
- Versões

Conhecimento (OKF) contém:
- editor Markdown;
- toolbar de formatação;
- modos Editar / Preview / Dividido;
- contagem de palavras/caracteres;
- salvamento versionado;
- restauração de versões;
- sugestões aplicáveis;
- chat Metis no painel direito.

## Alunos

`alunos.html`
- busca, filtros, ordenação, grade/lista;
- cadastro persistente de aluno;
- criação de matrícula, perfil Metis e progresso inicial.

`aluno.html`
- Resumo;
- Mapa de Compreensão;
- Atividades;
- Memória / Metis;
- edição persistente do aluno.

## Atividades

`atividades.html`

Abas implementadas:
- Visão Geral
- Questionários
- Sessões de Estudo
- Exercícios
- Simulados
- Intervenções IA

Inclui filtros, KPIs, criação persistente de atividade e navegação para a Activity.

`atividade.html`
- página própria da Activity;
- visão Administrador / Aluno;
- questionário uma questão por vez;
- revisão de resposta;
- confirmação e avaliação;
- ActivityEvent semântico;
- cálculo de score;
- atualização de StudentTopicProgress;
- monitoramento administrativo;
- chat durante a atividade.

## Relatórios

`relatorios.html`

Abas:
- Visão Geral
- Por Matéria
- Por Assunto
- Comparativos
- Atividades
- IA / Metis

O construtor persiste `ReportDefinition` e cada execução gera um `ReportRun` com snapshot.

`relatorio-materia.html`

Abas:
- Visão Geral
- Assuntos
- Evolução
- Atividades
- Insights (IA)

## Standalone

A pasta `standalone/` contém cada página com CSS + store + JS embutidos. Use esses arquivos para previews isolados.
