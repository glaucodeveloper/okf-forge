(() => {
  const KEY = 'studyStation.v3';
  const CHANNEL = 'study-station-v3';

  const clone = value => JSON.parse(JSON.stringify(value));
  const nowIso = () => new Date().toISOString();
  const uid = prefix => `${prefix}-${Date.now().toString(36)}-${Math.random().toString(36).slice(2,8)}`;

  function seed() {
    const subjects = [
      {uid:'subject-math',key:'matematica',title:'Matemática',description:'Estruturas matemáticas e resolução de problemas.',status:'active',order:1},
      {uid:'subject-physics',key:'fisica',title:'Física',description:'Mecânica, energia, ondas e eletromagnetismo.',status:'active',order:2},
      {uid:'subject-chemistry',key:'quimica',title:'Química',description:'Estrutura da matéria, reações e transformações.',status:'active',order:3},
      {uid:'subject-biology',key:'biologia',title:'Biologia',description:'Vida, organismos, genética e ecologia.',status:'active',order:4},
      {uid:'subject-portuguese',key:'portugues',title:'Português',description:'Linguagem, literatura e produção textual.',status:'active',order:5},
      {uid:'subject-history',key:'historia',title:'História',description:'Processos históricos e sociedades.',status:'active',order:6}
    ];

    const topics = [
      {uid:'topic-math',subjectUid:'subject-math',parentTopicUid:'',key:'matematica',slug:'matematica',title:'Matemática',summary:'Mapa principal de Matemática.',level:0,order:1,status:'active'},
      {uid:'topic-algebra',subjectUid:'subject-math',parentTopicUid:'topic-math',key:'algebra',slug:'algebra',title:'Álgebra',summary:'Estruturas algébricas, equações e funções.',level:1,order:1,status:'active'},
      {uid:'topic-functions',subjectUid:'subject-math',parentTopicUid:'topic-algebra',key:'funcoes',slug:'funcoes',title:'Funções',summary:'Relações funcionais, domínio e imagem.',level:2,order:1,status:'active'},
      {uid:'topic-linear',subjectUid:'subject-math',parentTopicUid:'topic-functions',key:'linear',slug:'funcao-linear',title:'Função Afim (1º grau)',summary:'Funções lineares e afins.',level:3,order:1,status:'active'},
      {uid:'topic-quadratic',subjectUid:'subject-math',parentTopicUid:'topic-functions',key:'quadratica',slug:'funcao-quadratica',title:'Função Quadrática (2º grau)',summary:'Funções do segundo grau, parábolas, vértice e raízes.',level:3,order:2,status:'active'},
      {uid:'topic-quad-graph',subjectUid:'subject-math',parentTopicUid:'topic-quadratic',key:'forma-grafico',slug:'forma-geral-grafico',title:'Forma Geral e Gráfico',summary:'Forma geral e interpretação gráfica.',level:4,order:1,status:'active'},
      {uid:'topic-quad-vertex',subjectUid:'subject-math',parentTopicUid:'topic-quadratic',key:'vertice',slug:'vertice',title:'Vértice',summary:'Coordenadas e interpretação do vértice.',level:4,order:2,status:'active'},
      {uid:'topic-quad-roots',subjectUid:'subject-math',parentTopicUid:'topic-quadratic',key:'raizes',slug:'raizes',title:'Raízes (Zeros)',summary:'Cálculo e significado das raízes.',level:4,order:3,status:'active'},
      {uid:'topic-quad-discriminant',subjectUid:'subject-math',parentTopicUid:'topic-quadratic',key:'discriminante',slug:'discriminante',title:'Discriminante (Δ)',summary:'Análise do discriminante.',level:4,order:4,status:'active'},
      {uid:'topic-geometry',subjectUid:'subject-math',parentTopicUid:'topic-math',key:'geometria',slug:'geometria',title:'Geometria',summary:'Formas, medidas e relações espaciais.',level:1,order:2,status:'active'},
      {uid:'topic-trig',subjectUid:'subject-math',parentTopicUid:'topic-math',key:'trigonometria',slug:'trigonometria',title:'Trigonometria',summary:'Relações angulares e trigonométricas.',level:1,order:3,status:'active'},
      {uid:'topic-statistics',subjectUid:'subject-math',parentTopicUid:'topic-math',key:'estatistica',slug:'estatistica',title:'Estatística',summary:'Análise e interpretação de dados.',level:1,order:4,status:'active'},
      {uid:'topic-physics',subjectUid:'subject-physics',parentTopicUid:'',key:'fisica',slug:'fisica',title:'Física',summary:'Mapa principal de Física.',level:0,order:1,status:'active'},
      {uid:'topic-vectors',subjectUid:'subject-physics',parentTopicUid:'topic-physics',key:'vetores',slug:'vetores',title:'Vetores',summary:'Representação e operações vetoriais.',level:1,order:1,status:'active'},
      {uid:'topic-force',subjectUid:'subject-physics',parentTopicUid:'topic-physics',key:'forca',slug:'conceitos-de-forca',title:'Conceitos de Força',summary:'Força, massa e aceleração.',level:1,order:2,status:'active'},
      {uid:'topic-chemistry',subjectUid:'subject-chemistry',parentTopicUid:'',key:'quimica',slug:'quimica',title:'Química',summary:'Mapa principal de Química.',level:0,order:1,status:'active'},
      {uid:'topic-reactions',subjectUid:'subject-chemistry',parentTopicUid:'topic-chemistry',key:'reacoes',slug:'reacoes-quimicas',title:'Reações Químicas',summary:'Tipos e velocidade das reações.',level:1,order:1,status:'active'}
    ];

    const topicRelations = [
      {uid:'rel-1',fromTopicUid:'topic-linear',toTopicUid:'topic-quadratic',kind:'prerequisite',weight:1,description:'Função afim como pré-requisito algébrico.'},
      {uid:'rel-2',fromTopicUid:'topic-quadratic',toTopicUid:'topic-trig',kind:'related',weight:.6,description:'Relações gráficas e aplicações.'},
      {uid:'rel-3',fromTopicUid:'topic-quadratic',toTopicUid:'topic-vectors',kind:'application',weight:.5,description:'Aplicação em lançamentos e movimento.'},
      {uid:'rel-4',fromTopicUid:'topic-quadratic',toTopicUid:'topic-geometry',kind:'related',weight:.7,description:'Interpretação geométrica da parábola.'}
    ];

    const topicMarkdown = `# Função Quadrática\n\n## 1. Definição\n\nUma função quadrática é toda função **f: ℝ → ℝ** definida por uma lei da forma:\n\n> $f(x) = ax² + bx + c$, com $a ≠ 0$.\n\nOnde:\n\n- $a, b, c ∈ ℝ$\n- $a ≠ 0$\n- $x ∈ ℝ$\n\n## 2. Gráfico\n\nO gráfico de uma função quadrática é uma **parábola**.\n\n- Se $a > 0$: concavidade voltada para cima.\n- Se $a < 0$: concavidade voltada para baixo.\n\n## 3. Vértice\n\nO vértice da parábola é o ponto de mudança do comportamento da função.\n\n> $x_v = -b / 2a$ e $y_v = f(x_v)$.\n\n## 4. Raízes\n\nAs raízes são os valores de $x$ para os quais $f(x)=0$. O discriminante é:\n\n> $Δ = b² - 4ac$\n\n### Interpretação\n\n- $Δ > 0$: duas raízes reais distintas.\n- $Δ = 0$: uma raiz real dupla.\n- $Δ < 0$: não há raízes reais.`;

    const topicDocuments = [
      {uid:'doc-quadratic',topicUid:'topic-quadratic',okfSpace:'Materias',okfId:'topic-quadratic',status:'published',currentVersion:4,checksum:'demo-v4',markdown:topicMarkdown,updatedByAccountUid:'account-admin',updatedAt:'2026-08-12T13:24:00.000Z'}
    ];

    const topicDocumentVersions = [
      {uid:'docv-1',topicDocumentUid:'doc-quadratic',topicUid:'topic-quadratic',version:1,markdown:topicMarkdown.split('## 3. Vértice')[0],changeSummary:'Versão inicial',createdByAccountUid:'account-admin',createdAt:'2026-08-08T12:30:00.000Z'},
      {uid:'docv-2',topicDocumentUid:'doc-quadratic',topicUid:'topic-quadratic',version:2,markdown:topicMarkdown.split('## 4. Raízes')[0],changeSummary:'Correções de notação',createdByAccountUid:'account-admin',createdAt:'2026-08-10T14:12:00.000Z'},
      {uid:'docv-3',topicDocumentUid:'doc-quadratic',topicUid:'topic-quadratic',version:3,markdown:topicMarkdown.replace('## 4. Raízes','## 4. Raízes\n\nObservação: relacione o discriminante com o número de interseções da parábola com o eixo x.'),changeSummary:'Inclusão de observações sobre interceptos',createdByAccountUid:'account-admin',createdAt:'2026-08-11T19:40:00.000Z'},
      {uid:'docv-4',topicDocumentUid:'doc-quadratic',topicUid:'topic-quadratic',version:4,markdown:topicMarkdown,changeSummary:'Ajustes em definições e exemplos',createdByAccountUid:'account-admin',createdAt:'2026-08-12T13:24:00.000Z'}
    ];

    const students = [
      {uid:'student-ana',code:'2026-0008',name:'Ana Souza',className:'2º ano B',status:'active',presence:'online',createdAt:'2026-02-01T12:00:00.000Z',updatedAt:'2026-08-12T17:21:00.000Z'},
      {uid:'student-icaro',code:'2026-0002',name:'Ícaro Costa',className:'2º ano A',status:'active',presence:'offline',createdAt:'2026-02-01T12:00:00.000Z',updatedAt:'2026-08-11T21:07:00.000Z'},
      {uid:'student-joao',code:'2026-0014',name:'João Lima',className:'2º ano B',status:'active',presence:'online',createdAt:'2026-02-01T12:00:00.000Z',updatedAt:'2026-08-12T16:42:00.000Z'},
      {uid:'student-maria',code:'2026-0019',name:'Maria Clara',className:'2º ano A',status:'active',presence:'offline',createdAt:'2026-02-01T12:00:00.000Z',updatedAt:'2026-08-10T19:33:00.000Z'},
      {uid:'student-rafael',code:'2026-0021',name:'Rafael Ferreira',className:'1º ano B',status:'active',presence:'online',createdAt:'2026-02-01T12:00:00.000Z',updatedAt:'2026-08-12T13:15:00.000Z'},
      {uid:'student-larissa',code:'2026-0027',name:'Larissa Brito',className:'2º ano A',status:'active',presence:'offline',createdAt:'2026-02-01T12:00:00.000Z',updatedAt:'2026-08-09T00:11:00.000Z'}
    ];

    const subjectScores = {
      'student-ana': [['subject-math',82],['subject-physics',73],['subject-chemistry',64],['subject-biology',58],['subject-portuguese',49]],
      'student-icaro': [['subject-math',72],['subject-physics',69],['subject-chemistry',63]],
      'student-joao': [['subject-math',54],['subject-physics',48],['subject-chemistry',41]],
      'student-maria': [['subject-math',61],['subject-physics',67],['subject-chemistry',66]],
      'student-rafael': [['subject-math',48],['subject-physics',42],['subject-chemistry',49]],
      'student-larissa': [['subject-math',30],['subject-physics',28],['subject-chemistry',35]]
    };

    const progress = [];
    const addProgress = (studentUid,subjectUid,topicUid,mastery,confidence=.78,studySeconds=3600,activityCount=4,questionCount=20,correctAnswerCount=Math.round(questionCount*mastery/100)) => {
      progress.push({uid:`progress-${studentUid}-${topicUid}`,studentUid,subjectUid,topicUid,mastery,confidence,band:mastery>=80?'high':mastery>=60?'medium':mastery>=40?'basic':'low',activityCount,completedActivityCount:Math.max(0,activityCount-1),questionCount,correctAnswerCount,answerRevisionCount:Math.max(0,Math.round(questionCount*.1)),studySeconds,lastActivityUid:'',lastActivityAt:'2026-08-12T17:21:00.000Z',learningSummary:'Evolução consistente no tópico.',difficultySummary:mastery<70?'Requer reforço conceitual e mais prática.':'Sem dificuldade crítica detectada.',updatedAt:'2026-08-12T17:21:00.000Z'});
    };
    Object.entries(subjectScores).forEach(([studentUid,items]) => items.forEach(([subjectUid,score]) => addProgress(studentUid,subjectUid,subjectUid==='subject-math'?'topic-math':subjectUid==='subject-physics'?'topic-physics':'topic-chemistry',score,.78,4200,5,24)));
    [['topic-algebra',88],['topic-functions',91],['topic-linear',96],['topic-quadratic',76],['topic-quad-graph',78],['topic-quad-vertex',74],['topic-quad-roots',72],['topic-quad-discriminant',70],['topic-geometry',67],['topic-trig',55],['topic-statistics',49]].forEach(([topicUid,score]) => addProgress('student-ana','subject-math',topicUid,score,.82,topicUid==='topic-quadratic'?16920:3600,topicUid==='topic-quadratic'?18:5,topicUid==='topic-quadratic'?80:20));

    const progressSamples = [];
    const sampleDates = ['2026-05-15','2026-05-29','2026-06-12','2026-06-26','2026-07-10','2026-07-24','2026-08-07','2026-08-12'];
    [44,50,60,64,63,72,78,82].forEach((mastery,i) => progressSamples.push({uid:`sample-ana-quadratic-${i}`,studentTopicProgressUid:'progress-student-ana-topic-quadratic',studentUid:'student-ana',topicUid:'topic-quadratic',activityUid:'',mastery,confidence:.72+i*.02,correctRate:Math.min(95,mastery+3),studySeconds:1200+i*200,measuredAt:`${sampleDates[i]}T12:00:00.000Z`}));

    const activities = [
      {uid:'activity-parabolas',studentUid:'student-ana',subjectUid:'subject-math',topicUid:'topic-quadratic',kind:'questionnaire',status:'completed',difficulty:'medium',title:'Parábolas e vértice',description:'Questões sobre forma e vértice',generatedBy:'question-generator',sourceTopicDocumentVersion:4,startedAt:'2026-08-12T13:39:00.000Z',completedAt:'2026-08-12T14:21:00.000Z',durationSeconds:2520,questionCount:10,answerCount:10,correctAnswerCount:9,answerRevisionCount:2,score:90,masteryBefore:74,masteryAfter:82,masteryGain:8,createdAt:'2026-08-12T13:35:00.000Z',updatedAt:'2026-08-12T14:21:00.000Z'},
      {uid:'activity-discriminant',studentUid:'student-ana',subjectUid:'subject-math',topicUid:'topic-quadratic',kind:'questionnaire',status:'completed',difficulty:'medium',title:'Discriminante e raízes',description:'Cálculo do discriminante e raízes',generatedBy:'question-generator',sourceTopicDocumentVersion:3,startedAt:'2026-08-09T14:47:00.000Z',completedAt:'2026-08-09T15:42:00.000Z',durationSeconds:3300,questionCount:20,answerCount:20,correctAnswerCount:16,answerRevisionCount:3,score:80,masteryBefore:68,masteryAfter:74,masteryGain:6,createdAt:'2026-08-09T14:40:00.000Z',updatedAt:'2026-08-09T15:42:00.000Z'},
      {uid:'activity-applications',studentUid:'student-ana',subjectUid:'subject-math',topicUid:'topic-quadratic',kind:'exercise',status:'completed',difficulty:'hard',title:'Aplicações em problemas',description:'Situações do dia a dia',generatedBy:'teacher',sourceTopicDocumentVersion:3,startedAt:'2026-08-07T10:06:00.000Z',completedAt:'2026-08-07T11:18:00.000Z',durationSeconds:4320,questionCount:10,answerCount:10,correctAnswerCount:7,answerRevisionCount:1,score:70,masteryBefore:58,masteryAfter:68,masteryGain:10,createdAt:'2026-08-07T10:00:00.000Z',updatedAt:'2026-08-07T11:18:00.000Z'},
      {uid:'activity-graph',studentUid:'student-ana',subjectUid:'subject-math',topicUid:'topic-quadratic',kind:'questionnaire',status:'completed',difficulty:'easy',title:'Interpretação do gráfico',description:'Leitura e análise de gráficos',generatedBy:'question-generator',sourceTopicDocumentVersion:2,startedAt:'2026-08-06T09:02:00.000Z',completedAt:'2026-08-06T09:30:00.000Z',durationSeconds:1680,questionCount:10,answerCount:10,correctAnswerCount:8,answerRevisionCount:1,score:80,masteryBefore:63,masteryAfter:68,masteryGain:5,createdAt:'2026-08-06T08:55:00.000Z',updatedAt:'2026-08-06T09:30:00.000Z'},
      {uid:'activity-vertex',studentUid:'student-ana',subjectUid:'subject-math',topicUid:'topic-quadratic',kind:'exercise',status:'completed',difficulty:'medium',title:'Vértice da parábola',description:'Determinação do vértice',generatedBy:'teacher',sourceTopicDocumentVersion:2,startedAt:'2026-08-05T15:29:00.000Z',completedAt:'2026-08-05T16:05:00.000Z',durationSeconds:2160,questionCount:12,answerCount:12,correctAnswerCount:9,answerRevisionCount:2,score:75,masteryBefore:61,masteryAfter:68,masteryGain:7,createdAt:'2026-08-05T15:25:00.000Z',updatedAt:'2026-08-05T16:05:00.000Z'},
      {uid:'activity-roots',studentUid:'student-ana',subjectUid:'subject-math',topicUid:'topic-quadratic',kind:'questionnaire',status:'in-progress',difficulty:'medium',title:'Raízes (Zeros)',description:'Encontrando as raízes da função',generatedBy:'question-generator',sourceTopicDocumentVersion:4,startedAt:'2026-08-12T17:24:00.000Z',completedAt:'',durationSeconds:0,questionCount:4,answerCount:1,correctAnswerCount:1,answerRevisionCount:2,score:25,masteryBefore:76,masteryAfter:76,masteryGain:0,createdAt:'2026-08-12T17:20:00.000Z',updatedAt:'2026-08-12T17:30:00.000Z'},
      {uid:'activity-study',studentUid:'student-ana',subjectUid:'subject-math',topicUid:'topic-quadratic',kind:'study-session',status:'completed',difficulty:'easy',title:'Função afim x quadrática',description:'Comparações e diferenças',generatedBy:'subject-monitor',sourceTopicDocumentVersion:2,startedAt:'2026-08-03T13:07:00.000Z',completedAt:'2026-08-03T14:12:00.000Z',durationSeconds:3900,questionCount:0,answerCount:0,correctAnswerCount:0,answerRevisionCount:0,score:0,masteryBefore:58,masteryAfter:61,masteryGain:3,createdAt:'2026-08-03T13:00:00.000Z',updatedAt:'2026-08-03T14:12:00.000Z'},
      {uid:'activity-simulated',studentUid:'student-ana',subjectUid:'subject-math',topicUid:'topic-quadratic',kind:'simulation',status:'available',difficulty:'hard',title:'Situações-desafio',description:'Questões desafiadoras',generatedBy:'question-generator',sourceTopicDocumentVersion:4,startedAt:'',completedAt:'',durationSeconds:0,questionCount:10,answerCount:0,correctAnswerCount:0,answerRevisionCount:0,score:0,masteryBefore:76,masteryAfter:76,masteryGain:0,createdAt:'2026-08-12T16:00:00.000Z',updatedAt:'2026-08-12T16:00:00.000Z'},
      {uid:'activity-vectors',studentUid:'student-ana',subjectUid:'subject-physics',topicUid:'topic-vectors',kind:'questionnaire',status:'completed',difficulty:'medium',title:'Vetores',description:'Operações vetoriais',generatedBy:'question-generator',sourceTopicDocumentVersion:1,startedAt:'2026-08-11T12:00:00.000Z',completedAt:'2026-08-11T13:33:00.000Z',durationSeconds:5580,questionCount:8,answerCount:8,correctAnswerCount:6,answerRevisionCount:2,score:75,masteryBefore:65,masteryAfter:71,masteryGain:6,createdAt:'2026-08-11T11:50:00.000Z',updatedAt:'2026-08-11T13:33:00.000Z'}
    ];

    const questionnaires = [
      {uid:'questionnaire-roots',activityUid:'activity-roots',studentUid:'student-ana',subjectUid:'subject-math',topicUid:'topic-quadratic',title:'Raízes (Zeros)',instructions:'Responda uma questão por vez. Você pode revisar antes de concluir.',generatedByAgent:'question-generator',requestedQuestionCount:4,actualQuestionCount:4,passingScore:70,createdAt:'2026-08-12T17:20:00.000Z'}
    ];

    const questions = [
      {uid:'question-roots-1',questionnaireUid:'questionnaire-roots',activityUid:'activity-roots',topicUid:'topic-quadratic',position:1,kind:'single-choice',difficulty:'easy',prompt:'Quais são as raízes de f(x) = x² - 5x + 6?',options:[{uid:'q1a',value:'1 e 6',label:'1 e 6',order:1},{uid:'q1b',value:'2 e 3',label:'2 e 3',order:2},{uid:'q1c',value:'-2 e -3',label:'-2 e -3',order:3},{uid:'q1d',value:'5 e 6',label:'5 e 6',order:4}],expected:'2 e 3',explanation:'Fatorando: (x-2)(x-3)=0, portanto x=2 ou x=3.',generatedByAgent:'question-generator',sourceEvidence:{topicDocumentVersion:4},createdAt:'2026-08-12T17:20:00.000Z'},
      {uid:'question-roots-2',questionnaireUid:'questionnaire-roots',activityUid:'activity-roots',topicUid:'topic-quadratic',position:2,kind:'single-choice',difficulty:'medium',prompt:'Para f(x)=x²+4x+4, qual é o valor do discriminante Δ?',options:[{uid:'q2a',value:'16',label:'16',order:1},{uid:'q2b',value:'8',label:'8',order:2},{uid:'q2c',value:'0',label:'0',order:3},{uid:'q2d',value:'-4',label:'-4',order:4}],expected:'0',explanation:'Δ=b²-4ac=16-16=0.',generatedByAgent:'question-generator',sourceEvidence:{topicDocumentVersion:4},createdAt:'2026-08-12T17:20:00.000Z'},
      {uid:'question-roots-3',questionnaireUid:'questionnaire-roots',activityUid:'activity-roots',topicUid:'topic-quadratic',position:3,kind:'short-text',difficulty:'medium',prompt:'Explique o que significa Δ < 0 para as raízes reais da função.',options:[],expected:'não há raízes reais',explanation:'Quando Δ<0, a equação não possui raízes no conjunto dos números reais.',generatedByAgent:'question-generator',sourceEvidence:{topicDocumentVersion:4},createdAt:'2026-08-12T17:20:00.000Z'},
      {uid:'question-roots-4',questionnaireUid:'questionnaire-roots',activityUid:'activity-roots',topicUid:'topic-quadratic',position:4,kind:'single-choice',difficulty:'hard',prompt:'Se uma parábola toca o eixo x em um único ponto, qual afirmação é correta?',options:[{uid:'q4a',value:'Δ > 0',label:'Δ > 0',order:1},{uid:'q4b',value:'Δ = 0',label:'Δ = 0',order:2},{uid:'q4c',value:'Δ < 0',label:'Δ < 0',order:3},{uid:'q4d',value:'a = 0',label:'a = 0',order:4}],expected:'Δ = 0',explanation:'Uma única interseção com o eixo x representa raiz dupla, então Δ=0.',generatedByAgent:'question-generator',sourceEvidence:{topicDocumentVersion:4},createdAt:'2026-08-12T17:20:00.000Z'}
    ];

    const answers = [
      {uid:'answer-roots-1',activityUid:'activity-roots',questionnaireUid:'questionnaire-roots',questionUid:'question-roots-1',studentUid:'student-ana',topicUid:'topic-quadratic',state:'evaluated',value:'2 e 3',revision:2,correct:true,score:100,confidence:.85,firstChangedAt:'2026-08-12T17:26:01.000Z',confirmedAt:'2026-08-12T17:26:31.000Z',evaluatedAt:'2026-08-12T17:26:31.000Z'}
    ];

    const activityEvents = [
      {uid:'event-1',activityUid:'activity-roots',studentUid:'student-ana',topicUid:'topic-quadratic',kind:'opened',sequence:1,payload:{},at:'2026-08-12T17:24:00.000Z'},
      {uid:'event-2',activityUid:'activity-roots',studentUid:'student-ana',topicUid:'topic-quadratic',kind:'question-opened',sequence:2,payload:{questionUid:'question-roots-1'},at:'2026-08-12T17:24:04.000Z'},
      {uid:'event-3',activityUid:'activity-roots',studentUid:'student-ana',topicUid:'topic-quadratic',kind:'answer-changed',sequence:3,payload:{questionUid:'question-roots-1',value:'1 e 6'},at:'2026-08-12T17:25:13.000Z'},
      {uid:'event-4',activityUid:'activity-roots',studentUid:'student-ana',topicUid:'topic-quadratic',kind:'answer-changed',sequence:4,payload:{questionUid:'question-roots-1',value:'2 e 3'},at:'2026-08-12T17:26:01.000Z'},
      {uid:'event-5',activityUid:'activity-roots',studentUid:'student-ana',topicUid:'topic-quadratic',kind:'answer-confirmed',sequence:5,payload:{questionUid:'question-roots-1',value:'2 e 3',correct:true},at:'2026-08-12T17:26:31.000Z'}
    ];

    const topicChatThreads = [{uid:'thread-quadratic',topicUid:'topic-quadratic',topicDocumentUid:'doc-quadratic',createdByAccountUid:'account-admin',metisSession:'topic:quadratic:admin',createdAt:'2026-08-12T13:20:00.000Z',updatedAt:'2026-08-12T13:31:00.000Z'}];
    const topicChatMessages = [
      {uid:'msg-1',threadUid:'thread-quadratic',role:'administrator',content:'Pode sugerir uma explicação alternativa para o vértice?',documentVersion:4,createdAt:'2026-08-12T13:24:00.000Z'},
      {uid:'msg-2',threadUid:'thread-quadratic',role:'assistant',content:'O vértice é o ponto em que a parábola muda de direção. Se a > 0, ele é o ponto de mínimo; se a < 0, é o ponto de máximo. Ele resume o ponto de equilíbrio do gráfico.',documentVersion:4,createdAt:'2026-08-12T13:24:15.000Z'}
    ];
    const topicDocumentSuggestions = [
      {uid:'sug-1',threadUid:'thread-quadratic',topicUid:'topic-quadratic',topicDocumentUid:'doc-quadratic',baseVersion:4,title:'Adicionar exemplo prático',explanation:'Inclua um exemplo numérico logo após a definição para reduzir abstração.',patch:{append:'\n\n### Exemplo\n\nPara f(x)=x²-6x+5, o vértice ocorre em x=3 e y=-4.'},status:'open',createdAt:'2026-08-12T13:25:00.000Z',resolvedAt:''},
      {uid:'sug-2',threadUid:'thread-quadratic',topicUid:'topic-quadratic',topicDocumentUid:'doc-quadratic',baseVersion:4,title:'Explicar discriminante',explanation:'Relacione Δ com o número de interseções da parábola com o eixo x.',patch:{append:'\n\n> O discriminante indica quantas vezes a parábola cruza ou toca o eixo x.'},status:'open',createdAt:'2026-08-12T13:26:00.000Z',resolvedAt:''}
    ];

    const reportDefinitions = [
      {uid:'report-subject-performance',title:'Desempenho geral por matéria',description:'Visão da turma completa',dimensions:['subject'],metrics:['averageMastery','answerAccuracy','studyTime'],filters:[],groupBy:'subject',visualization:'bars',createdByAccountUid:'account-admin',createdAt:'2026-08-01T10:00:00.000Z',updatedAt:'2026-08-12T13:21:00.000Z'},
      {uid:'report-hard-topics',title:'Assuntos com maior dificuldade',description:'Comparativo entre turmas',dimensions:['topic','class'],metrics:['averageMastery','questionErrorRate'],filters:[],groupBy:'topic',visualization:'table',createdByAccountUid:'account-admin',createdAt:'2026-08-02T10:00:00.000Z',updatedAt:'2026-08-12T12:15:00.000Z'}
    ];

    const reportRuns = [
      {uid:'run-subject-performance',reportUid:'report-subject-performance',periodStart:'2026-07-01',periodEnd:'2026-08-12',resultSnapshot:{},generatedAt:'2026-08-12T13:21:00.000Z'},
      {uid:'run-hard-topics',reportUid:'report-hard-topics',periodStart:'2026-07-01',periodEnd:'2026-08-12',resultSnapshot:{},generatedAt:'2026-08-12T12:15:00.000Z'}
    ];

    const reportInsights = [
      {uid:'insight-1',reportRunUid:'run-subject-performance',kind:'difficulty',title:'Gargalos principais',description:'Função Quadrática e Trigonometria concentram os menores índices de domínio.',evidence:{topics:['topic-quadratic','topic-trig']},confidence:.92,generatedBy:'Metis',createdAt:'2026-08-12T13:21:00.000Z'},
      {uid:'insight-2',reportRunUid:'run-subject-performance',kind:'correlation',title:'Tempo de estudo',description:'Alunos com mais de 2h semanais apresentaram ganho médio de 7 p.p.',evidence:{thresholdMinutes:120,gain:7},confidence:.81,generatedBy:'Metis',createdAt:'2026-08-12T13:21:00.000Z'}
    ];

    return {
      schemaVersion:3,
      settings:{webHost:'127.0.0.1',webPort:8765,metisHost:'127.0.0.1',metisPort:19192,metisEndpoint:'http://127.0.0.1:19192/v1/chat/completions',metisEnabled:true,tunnelEnabled:false},
      accounts:[{uid:'account-admin',role:'administrator',displayName:'Administrador',email:'admin@station.local',status:'active',createdAt:'2026-01-01T00:00:00.000Z',updatedAt:'2026-08-12T00:00:00.000Z'}],
      subjects,topics,topicRelations,topicDocuments,topicDocumentVersions,
      topicChatThreads,topicChatMessages,topicDocumentSuggestions,
      students,enrollments:students.flatMap(s=>subjects.slice(0,4).map(subject=>({uid:`enrollment-${s.uid}-${subject.uid}`,studentUid:s.uid,subjectUid:subject.uid,enrolledAt:'2026-02-01T12:00:00.000Z',completedAt:'',active:true}))),
      studentMemoryProfiles:students.map(s=>({uid:`memory-${s.uid}`,studentUid:s.uid,profileKey:s.uid,metisSession:`student:${s.uid}`,memoryStateRef:`memory/profiles/${s.uid}`,lastRecordedAt:s.updatedAt,updatedAt:s.updatedAt})),
      studentTopicProgress:progress,studentTopicProgressSamples:progressSamples,
      activities,questionnaires,questions,answers,activityEvents,
      studyAccessTokens:[],clientPresence:[],reportDefinitions,reportRuns,reportInsights
    };
  }

  class StudyStore {
    constructor() {
      this.listeners = new Set();
      this.memoryRaw = '';
      this.storagePersistent = false;
      this.channel = null;

      try {
        const probe = `${KEY}.probe`;
        localStorage.setItem(probe, '1');
        localStorage.removeItem(probe);
        this.storagePersistent = true;
      } catch (_) {
        // Previews com origem opaca podem bloquear localStorage. O store ainda
        // funciona em memória para permitir testar todas as funcionalidades.
        this.storagePersistent = false;
      }

      try {
        if ('BroadcastChannel' in window) {
          this.channel = new BroadcastChannel(CHANNEL);
        }
      } catch (_) {
        this.channel = null;
      }

      if (this.channel) {
        this.channel.onmessage = () => {
          this.data = this.load();
          this.notify(false);
        };
      }

      window.addEventListener('storage', e => {
        if (e.key === KEY) {
          this.data = this.load();
          this.notify(false);
        }
      });

      this.data = this.load();
    }
    readRaw() {
      if (this.storagePersistent) {
        try { return localStorage.getItem(KEY) || ''; } catch (_) {}
      }
      return this.memoryRaw || '';
    }
    writeRaw(value) {
      this.memoryRaw = value;
      if (this.storagePersistent) {
        try { localStorage.setItem(KEY, value); return true; } catch (_) {
          this.storagePersistent = false;
        }
      }
      return false;
    }
    load() {
      try {
        const raw = this.readRaw();
        if (!raw) {
          const initial = seed();
          this.writeRaw(JSON.stringify(initial));
          return initial;
        }
        const parsed = JSON.parse(raw);
        if (!parsed || parsed.schemaVersion !== 3) {
          const initial = seed();
          this.writeRaw(JSON.stringify(initial));
          return initial;
        }
        return parsed;
      } catch (_) {
        const initial = seed();
        this.writeRaw(JSON.stringify(initial));
        return initial;
      }
    }
    save(reason='update') {
      this.writeRaw(JSON.stringify(this.data));
      if (this.channel) {
        try { this.channel.postMessage({reason,at:nowIso()}); } catch (_) {}
      }
      this.notify(true);
      return this.data;
    }
    subscribe(fn) { this.listeners.add(fn); return () => this.listeners.delete(fn); }
    notify(local=true) { this.listeners.forEach(fn => fn(this.data,{local})); }
    reset() { this.data = seed(); this.save('reset'); return this.data; }
    table(name) { return this.data[name] || []; }
    get(name, id) { return this.table(name).find(x => x.uid === id); }
    find(name, predicate) { return this.table(name).find(predicate); }
    filter(name, predicate) { return this.table(name).filter(predicate); }
    upsert(name, row) {
      const rows = this.table(name);
      const index = rows.findIndex(x => x.uid === row.uid);
      if (index >= 0) rows[index] = {...rows[index], ...clone(row)};
      else rows.push(clone(row));
      this.data[name] = rows;
      this.save(`upsert:${name}`);
      return index >= 0 ? rows[index] : rows[rows.length-1];
    }
    remove(name, id) {
      this.data[name] = this.table(name).filter(x => x.uid !== id);
      this.save(`remove:${name}`);
    }
    makeUid(prefix) { return uid(prefix); }
    now() { return nowIso(); }

    subject(idOrKey) { return this.find('subjects', x => x.uid === idOrKey || x.key === idOrKey); }
    topic(idOrSlug) { return this.find('topics', x => x.uid === idOrSlug || x.slug === idOrSlug || x.key === idOrSlug); }
    student(id) { return this.get('students', id) || this.table('students')[0]; }
    topicChildren(topicUid) { return this.filter('topics', x => x.parentTopicUid === topicUid).sort((a,b)=>a.order-b.order); }
    topicAncestors(topicUid) {
      const result=[]; let current=this.topic(topicUid); const seen=new Set();
      while (current && current.parentTopicUid && !seen.has(current.uid)) { seen.add(current.uid); current=this.topic(current.parentTopicUid); if (current) result.unshift(current); }
      return result;
    }
    progress(studentUid, topicUid) { return this.find('studentTopicProgress', x => x.studentUid === studentUid && x.topicUid === topicUid); }
    progressForStudent(studentUid) { return this.filter('studentTopicProgress', x => x.studentUid === studentUid); }
    subjectProgress(studentUid, subjectUid) {
      const rootTopic = this.find('topics', x => x.subjectUid===subjectUid && !x.parentTopicUid);
      return rootTopic ? this.progress(studentUid, rootTopic.uid) : null;
    }
    activitiesFor({studentUid='',topicUid='',subjectUid='',kind='',status=''}={}) {
      return this.table('activities').filter(a => (!studentUid||a.studentUid===studentUid)&&(!topicUid||a.topicUid===topicUid)&&(!subjectUid||a.subjectUid===subjectUid)&&(!kind||a.kind===kind)&&(!status||a.status===status)).sort((a,b)=>(b.updatedAt||'').localeCompare(a.updatedAt||''));
    }
    activity(id) { return this.get('activities', id); }
    questionnaireForActivity(activityUid) { return this.find('questionnaires', x => x.activityUid === activityUid); }
    questionsForActivity(activityUid) { return this.filter('questions', x => x.activityUid === activityUid).sort((a,b)=>a.position-b.position); }
    answerFor(questionUid, studentUid) { return this.find('answers', x => x.questionUid === questionUid && x.studentUid === studentUid); }
    eventsForActivity(activityUid) { return this.filter('activityEvents', x => x.activityUid === activityUid).sort((a,b)=>a.sequence-b.sequence); }
    appendActivityEvent(activityUid, kind, payload={}) {
      const a = this.activity(activityUid); if (!a) return null;
      const events = this.eventsForActivity(activityUid);
      const row = {uid:uid('event'),activityUid,studentUid:a.studentUid,topicUid:a.topicUid,kind,sequence:(events.at(-1)?.sequence||0)+1,payload:clone(payload),at:nowIso()};
      this.data.activityEvents.push(row); this.save(`event:${kind}`); return row;
    }
    createStudent(input) {
      const student = {uid:uid('student'),code:input.code||`2026-${String(this.data.students.length+1).padStart(4,'0')}`,name:input.name.trim(),className:input.className.trim(),status:'active',presence:'offline',createdAt:nowIso(),updatedAt:nowIso()};
      this.data.students.push(student);
      this.data.subjects.slice(0,4).forEach(subject => {
        this.data.enrollments.push({uid:uid('enrollment'),studentUid:student.uid,subjectUid:subject.uid,enrolledAt:nowIso(),completedAt:'',active:true});
        const root = this.find('topics', x => x.subjectUid===subject.uid && !x.parentTopicUid);
        if (root) this.data.studentTopicProgress.push({uid:uid('progress'),studentUid:student.uid,subjectUid:subject.uid,topicUid:root.uid,mastery:0,confidence:0,band:'low',activityCount:0,completedActivityCount:0,questionCount:0,correctAnswerCount:0,answerRevisionCount:0,studySeconds:0,lastActivityUid:'',lastActivityAt:'',learningSummary:'Sem atividades registradas.',difficultySummary:'Sem dados suficientes.',updatedAt:nowIso()});
      });
      this.data.studentMemoryProfiles.push({uid:uid('memory'),studentUid:student.uid,profileKey:student.uid,metisSession:`student:${student.uid}`,memoryStateRef:`memory/profiles/${student.uid}`,lastRecordedAt:'',updatedAt:nowIso()});
      this.save('student:create'); return student;
    }
    updateStudent(studentUid, patch) {
      const student = this.student(studentUid); if (!student) return null;
      Object.assign(student, patch, {updatedAt:nowIso()}); this.save('student:update'); return student;
    }
    saveTopicDocument(topicUid, markdown, actor='account-admin', summary='Edição manual') {
      let doc = this.find('topicDocuments', x => x.topicUid === topicUid);
      if (!doc) { doc={uid:uid('doc'),topicUid,okfSpace:'Materias',okfId:topicUid,status:'draft',currentVersion:0,checksum:'',markdown:'',updatedByAccountUid:actor,updatedAt:nowIso()}; this.data.topicDocuments.push(doc); }
      const version = (doc.currentVersion||0)+1;
      const checksum = `${markdown.length}:${markdown.split('').reduce((a,c)=>(a+c.charCodeAt(0))%1000003,0)}`;
      doc.markdown=markdown; doc.currentVersion=version; doc.checksum=checksum; doc.updatedByAccountUid=actor; doc.updatedAt=nowIso(); doc.status='published';
      this.data.topicDocumentVersions.push({uid:uid('docv'),topicDocumentUid:doc.uid,topicUid,version,markdown,checksum,changeSummary:summary,createdByAccountUid:actor,createdAt:nowIso()});
      this.save('topic-document:save'); return doc;
    }
    restoreTopicVersion(versionUid) {
      const version=this.get('topicDocumentVersions',versionUid); if(!version) return null;
      return this.saveTopicDocument(version.topicUid, version.markdown, 'account-admin', `Restaurada a versão ${version.version}`);
    }
    chatThreadForTopic(topicUid) {
      let thread=this.find('topicChatThreads',x=>x.topicUid===topicUid);
      if(!thread){ const doc=this.find('topicDocuments',x=>x.topicUid===topicUid); thread={uid:uid('thread'),topicUid,topicDocumentUid:doc?.uid||'',createdByAccountUid:'account-admin',metisSession:`topic:${topicUid}:admin`,createdAt:nowIso(),updatedAt:nowIso()}; this.data.topicChatThreads.push(thread); this.save('chat:thread'); }
      return thread;
    }
    addChatMessage(topicUid, role, content) {
      const thread=this.chatThreadForTopic(topicUid); const doc=this.find('topicDocuments',x=>x.topicUid===topicUid);
      const row={uid:uid('msg'),threadUid:thread.uid,role,content,documentVersion:doc?.currentVersion||0,createdAt:nowIso()};
      this.data.topicChatMessages.push(row); thread.updatedAt=nowIso(); this.save('chat:message'); return row;
    }
    addSuggestion(topicUid, title, explanation, patch) {
      const thread=this.chatThreadForTopic(topicUid); const doc=this.find('topicDocuments',x=>x.topicUid===topicUid);
      const row={uid:uid('sug'),threadUid:thread.uid,topicUid,topicDocumentUid:doc?.uid||'',baseVersion:doc?.currentVersion||0,title,explanation,patch:clone(patch),status:'open',createdAt:nowIso(),resolvedAt:''};
      this.data.topicDocumentSuggestions.push(row); this.save('suggestion:create'); return row;
    }
    applySuggestion(suggestionUid) {
      const s=this.get('topicDocumentSuggestions',suggestionUid); if(!s||s.status!=='open') return null;
      const doc=this.find('topicDocuments',x=>x.topicUid===s.topicUid); let markdown=doc?.markdown||'';
      if (s.patch?.append) markdown += s.patch.append;
      if (s.patch?.replace && Array.isArray(s.patch.replace)) s.patch.replace.forEach(pair=>{markdown=markdown.replace(pair.from,pair.to)});
      const saved=this.saveTopicDocument(s.topicUid,markdown,'account-admin',`Sugestão aplicada: ${s.title}`); s.status='applied'; s.resolvedAt=nowIso(); this.save('suggestion:apply'); return saved;
    }
    rejectSuggestion(suggestionUid) { const s=this.get('topicDocumentSuggestions',suggestionUid); if(!s)return; s.status='rejected';s.resolvedAt=nowIso();this.save('suggestion:reject'); }
    createActivity(input) {
      const student=this.student(input.studentUid); const topic=this.topic(input.topicUid); const subject=this.subject(topic?.subjectUid||input.subjectUid); if(!student||!topic||!subject) throw new Error('Aluno, matéria ou tópico inválido.');
      const activity={uid:uid('activity'),studentUid:student.uid,subjectUid:subject.uid,topicUid:topic.uid,kind:input.kind||'questionnaire',status:input.status||'available',difficulty:input.difficulty||'medium',title:input.title||`Atividade · ${topic.title}`,description:input.description||'',generatedBy:input.generatedBy||'administrator',sourceTopicDocumentVersion:this.find('topicDocuments',x=>x.topicUid===topic.uid)?.currentVersion||0,startedAt:'',completedAt:'',durationSeconds:0,questionCount:0,answerCount:0,correctAnswerCount:0,answerRevisionCount:0,score:0,masteryBefore:this.progress(student.uid,topic.uid)?.mastery||0,masteryAfter:this.progress(student.uid,topic.uid)?.mastery||0,masteryGain:0,createdAt:nowIso(),updatedAt:nowIso()};
      this.data.activities.push(activity);
      if(activity.kind==='questionnaire'){
        const questionnaire={uid:uid('questionnaire'),activityUid:activity.uid,studentUid:student.uid,subjectUid:subject.uid,topicUid:topic.uid,title:activity.title,instructions:'Responda uma questão por vez.',generatedByAgent:'question-generator',requestedQuestionCount:Number(input.questionCount||5),actualQuestionCount:0,passingScore:70,createdAt:nowIso()}; this.data.questionnaires.push(questionnaire);
        const template=[
          {prompt:`Qual afirmação descreve melhor ${topic.title}?`,options:['Uma relação matemática','Um conceito sem relação','Uma constante fixa','Nenhuma das anteriores'],expected:'Uma relação matemática'},
          {prompt:`Qual é uma propriedade importante de ${topic.title}?`,options:['Pode ser analisado por relações','Nunca possui representação','Não admite exemplos','É sempre constante'],expected:'Pode ser analisado por relações'},
          {prompt:`Escreva, em uma frase, o que você entendeu sobre ${topic.title}.`,options:[],expected:'resposta aberta'}
        ];
        const count=Math.max(1,Number(input.questionCount||5));
        for(let i=0;i<count;i++){ const t=template[i%template.length]; this.data.questions.push({uid:uid('question'),questionnaireUid:questionnaire.uid,activityUid:activity.uid,topicUid:topic.uid,position:i+1,kind:t.options.length?'single-choice':'short-text',difficulty:activity.difficulty,prompt:t.prompt,options:t.options.map((label,j)=>({uid:uid('option'),value:label,label,order:j+1})),expected:t.expected,explanation:'Explicação gerada a partir do documento OKF do tópico.',generatedByAgent:'question-generator',sourceEvidence:{topicDocumentVersion:activity.sourceTopicDocumentVersion},createdAt:nowIso()}); }
        activity.questionCount=count; questionnaire.actualQuestionCount=count;
      }
      this.save('activity:create'); return activity;
    }
    updateActivity(activityUid, patch) { const a=this.activity(activityUid); if(!a)return null; Object.assign(a,patch,{updatedAt:nowIso()}); this.save('activity:update'); return a; }
    saveAnswer(activityUid, questionUid, value, confirmed=false) {
      const a=this.activity(activityUid); const q=this.get('questions',questionUid); if(!a||!q)return null;
      let answer=this.answerFor(questionUid,a.studentUid); const now=nowIso();
      if(!answer){ answer={uid:uid('answer'),activityUid,questionnaireUid:q.questionnaireUid,questionUid,studentUid:a.studentUid,topicUid:a.topicUid,state:'editing',value:'',revision:0,correct:false,score:0,confidence:0,firstChangedAt:now,confirmedAt:'',evaluatedAt:''}; this.data.answers.push(answer); }
      if(JSON.stringify(answer.value)!==JSON.stringify(value)){ answer.value=clone(value); answer.revision=(answer.revision||0)+1; if(!answer.firstChangedAt)answer.firstChangedAt=now; this.appendActivityEvent(activityUid,'answer-changed',{questionUid,value,revision:answer.revision}); }
      if(confirmed){
        answer.state='evaluated'; answer.confirmedAt=now; answer.evaluatedAt=now;
        const normalized=String(value||'').toLowerCase().replace(/\s+/g,' ').trim(); const expected=String(q.expected||'').toLowerCase().replace(/\s+/g,' ').trim();
        answer.correct=q.kind==='short-text'?normalized.includes(expected.split(' ').slice(0,3).join(' '))||normalized.length>18:normalized===expected;
        answer.score=answer.correct?100:0;
        this.appendActivityEvent(activityUid,'answer-confirmed',{questionUid,value,correct:answer.correct,revision:answer.revision});
      }
      const answers=this.filter('answers',x=>x.activityUid===activityUid&&x.state==='evaluated');
      a.answerCount=answers.length;a.correctAnswerCount=answers.filter(x=>x.correct).length;a.answerRevisionCount=answers.reduce((s,x)=>s+(x.revision||0),0);a.score=a.questionCount?Math.round(a.correctAnswerCount/a.questionCount*100):0;
      if(a.questionCount>0&&a.answerCount>=a.questionCount){a.status='completed';a.completedAt=now;a.masteryAfter=Math.min(100,a.masteryBefore+Math.round((a.score-50)/10));a.masteryGain=a.masteryAfter-a.masteryBefore;this.appendActivityEvent(activityUid,'completed',{score:a.score});this.recalculateProgress(a.studentUid,a.topicUid);}
      a.updatedAt=now; this.save('answer:save'); return answer;
    }
    recalculateProgress(studentUid, topicUid) {
      const acts=this.activitiesFor({studentUid,topicUid}); let p=this.progress(studentUid,topicUid); const topic=this.topic(topicUid); if(!p){p={uid:uid('progress'),studentUid,subjectUid:topic.subjectUid,topicUid,mastery:0,confidence:.5,band:'low',activityCount:0,completedActivityCount:0,questionCount:0,correctAnswerCount:0,answerRevisionCount:0,studySeconds:0,lastActivityUid:'',lastActivityAt:'',learningSummary:'',difficultySummary:'',updatedAt:nowIso()};this.data.studentTopicProgress.push(p);}
      const completed=acts.filter(a=>a.status==='completed'); const weighted=completed.filter(a=>a.questionCount>0); const mastery=weighted.length?weighted.reduce((s,a)=>s+a.score,0)/weighted.length:p.mastery;
      p.mastery=Math.round((p.mastery*0.45+mastery*0.55)*10)/10;p.band=p.mastery>=80?'high':p.mastery>=60?'medium':p.mastery>=40?'basic':'low';p.activityCount=acts.length;p.completedActivityCount=completed.length;p.questionCount=acts.reduce((s,a)=>s+a.questionCount,0);p.correctAnswerCount=acts.reduce((s,a)=>s+a.correctAnswerCount,0);p.answerRevisionCount=acts.reduce((s,a)=>s+a.answerRevisionCount,0);p.studySeconds=acts.reduce((s,a)=>s+a.durationSeconds,0);p.lastActivityUid=acts[0]?.uid||'';p.lastActivityAt=acts[0]?.updatedAt||'';p.updatedAt=nowIso();
      this.data.studentTopicProgressSamples.push({uid:uid('sample'),studentTopicProgressUid:p.uid,studentUid,topicUid,activityUid:p.lastActivityUid,mastery:p.mastery,confidence:p.confidence,correctRate:p.questionCount?p.correctAnswerCount/p.questionCount*100:0,studySeconds:p.studySeconds,measuredAt:nowIso()});
      this.save('progress:recalculate'); return p;
    }
    createReportDefinition(input) {
      const report={uid:uid('report'),title:input.title||'Novo relatório',description:input.description||'Relatório construído no Study Station.',dimensions:clone(input.dimensions||[]),metrics:clone(input.metrics||[]),filters:clone(input.filters||[]),groupBy:input.groupBy||input.dimensions?.[0]||'subject',visualization:input.visualization||'table',createdByAccountUid:'account-admin',createdAt:nowIso(),updatedAt:nowIso()};
      this.data.reportDefinitions.push(report); const run=this.runReport(report); this.save('report:create'); return {report,run};
    }
    runReport(reportOrUid, periodStart='2026-07-01', periodEnd='2026-08-12') {
      const report=typeof reportOrUid==='string'?this.get('reportDefinitions',reportOrUid):reportOrUid; if(!report)return null;
      const snapshot=this.reportSnapshot(report); const run={uid:uid('run'),reportUid:report.uid,periodStart,periodEnd,resultSnapshot:snapshot,generatedAt:nowIso()}; this.data.reportRuns.push(run); report.updatedAt=nowIso(); return run;
    }
    reportSnapshot(report) {
      const topicRows=this.table('studentTopicProgress').filter(p=>this.topic(p.topicUid));
      const avg=arr=>arr.length?arr.reduce((s,v)=>s+Number(v||0),0)/arr.length:0;
      const bySubject=this.data.subjects.map(subject=>{const vals=topicRows.filter(p=>p.subjectUid===subject.uid&&this.topic(p.topicUid)?.level===0);return {uid:subject.uid,title:subject.title,mastery:Math.round(avg(vals.map(v=>v.mastery))),students:new Set(vals.map(v=>v.studentUid)).size};});
      const topicScores=this.data.topics.map(topic=>{const vals=topicRows.filter(p=>p.topicUid===topic.uid);return {uid:topic.uid,title:topic.title,subjectUid:topic.subjectUid,mastery:Math.round(avg(vals.map(v=>v.mastery))),students:vals.length};}).filter(x=>x.students).sort((a,b)=>a.mastery-b.mastery);
      const activities=this.data.activities; const completed=activities.filter(a=>a.status==='completed');
      return {averageMastery:Math.round(avg(topicRows.map(p=>p.mastery))),answerAccuracy:Math.round(avg(completed.filter(a=>a.questionCount).map(a=>a.score))),completedActivities:completed.length,studySeconds:completed.reduce((s,a)=>s+a.durationSeconds,0),activeStudents:new Set(activities.map(a=>a.studentUid)).size,bySubject,hardTopics:topicScores.slice(0,8)};
    }
    settings(patch) { Object.assign(this.data.settings,patch); this.save('settings:update'); return this.data.settings; }
  }

  window.StudyStore = new StudyStore();
  window.StudySeed = seed;
})();
