#!/usr/bin/env python3
from pathlib import Path
import re, shutil
root=Path(__file__).resolve().parent
out=root/'standalone';out.mkdir(exist_ok=True)
css=(root/'assets/styles.css').read_text(encoding='utf-8')
store=(root/'assets/store.js').read_text(encoding='utf-8')
app=(root/'assets/app.js').read_text(encoding='utf-8')
for path in root.glob('*.html'):
    text=path.read_text(encoding='utf-8')
    text=text.replace('<link rel="stylesheet" href="assets/styles.css">', '<style>\n'+css+'\n</style>')
    text=text.replace('<script src="assets/store.js"></script>', '<script>\n'+store+'\n</script>')
    text=text.replace('<script src="assets/app.js"></script>', '<script>\n'+app+'\n</script>')
    (out/path.name).write_text(text,encoding='utf-8')
print(f'Built {len(list(root.glob("*.html")))} standalone pages in {out}')
