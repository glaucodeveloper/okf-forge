#!/usr/bin/env python3
from pathlib import Path
import subprocess, sys
root=Path(__file__).resolve().parent
checks={
 'Markdown editor':['data-md-toolbar','data-editor-view','data-save-doc','markdownToHtml'],
 'Topic tabs':['Conhecimento (OKF)','Estrutura','Relações','Atividades','Versões'],
 'Activity tabs':['Questionários','Sessões de Estudo','Exercícios','Simulados','Intervenções IA'],
 'Activity detail':['renderActivityPage','data-confirm-answer','adminMonitorHtml','studentMonitorHtml'],
 'Report tabs':['Por Matéria','Por Assunto','Comparativos','IA / Metis'],
 'Report detail tabs':['Assuntos','Evolução','Insights (IA)'],
 'Persistence':['localStorage','BroadcastChannel','studentTopicProgress','activityEvents','reportRuns'],
}
text=(root/'assets/app.js').read_text(encoding='utf-8')+'\n'+(root/'assets/store.js').read_text(encoding='utf-8')
errors=[]
for title,needles in checks.items():
    missing=[x for x in needles if x not in text]
    print(f"[{ 'OK' if not missing else 'FAIL' }] {title}")
    if missing: errors.append((title,missing))
for js in ['store.js','app.js']:
    result=subprocess.run(['node','--check',str(root/'assets'/js)],capture_output=True,text=True)
    print(f"[{ 'OK' if result.returncode==0 else 'FAIL' }] syntax {js}")
    if result.returncode: errors.append((js,[result.stderr]))
raise SystemExit(1 if errors else 0)
