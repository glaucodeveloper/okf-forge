# Study Station — relações do domínio

Subject
  └─ Topic
      ├─ TopicRelation ────────────────> Topic
      └─ TopicDocumentRef ─────────────> OKF document
            ├─ TopicDocumentVersion
            └─ TopicChatThread
                 ├─ TopicChatMessage
                 └─ TopicDocumentSuggestion

Student
  ├─ Enrollment ──────────────────────> Subject
  ├─ StudentMemoryProfile ────────────> Metis session/profile
  └─ StudentTopicProgress
       ├─ StudentTopicProgressSample
       └─ Activity
            ├─ Questionnaire
            │    └─ Question
            │         └─ Answer
            └─ ActivityEvent

ReportDefinition
  └─ ReportRun
       └─ ReportInsight

Navegação:

/materias
/materias/:topicSlug

/alunos
/alunos/:studentUid
/alunos/:studentUid/materias/:subjectKey/assuntos/:topicSlug
/alunos/:studentUid/materias/:subjectKey/assuntos/:topicSlug/atividades/:activityUid

/relatorios
/relatorios/:reportUid

/estudar/:opaqueToken
