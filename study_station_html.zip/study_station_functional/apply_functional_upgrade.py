#!/usr/bin/env python3
"""Instala o protótipo funcional Study Station sobre uma pasta de destino."""
from pathlib import Path
import shutil, sys

source = Path(__file__).resolve().parent
if len(sys.argv) != 2:
    raise SystemExit("Uso: python apply_functional_upgrade.py /caminho/do/frontend")
target = Path(sys.argv[1]).expanduser().resolve()
target.mkdir(parents=True, exist_ok=True)
for name in [
    "index.html", "alunos.html", "aluno.html", "materia-topico.html",
    "atividades.html", "atividade.html", "relatorios.html",
    "relatorio-materia.html", "configuracoes.html"
]:
    shutil.copy2(source / name, target / name)
for dirname in ["assets", "domain"]:
    dst = target / dirname
    if dst.exists():
        shutil.rmtree(dst)
    shutil.copytree(source / dirname, dst)
print(f"[OK] Study Station funcional instalada em {target}")
print("[OK] Execute build_standalone.py se quiser HTMLs autocontidos.")
