param(
  [string]$Root = $PSScriptRoot,
  [switch]$Wait
)
$ErrorActionPreference = 'Stop'
$python = if ($env:OKFFORGE_PYTHON) { $env:OKFFORGE_PYTHON } else { 'python' }
& $python (Join-Path $Root 'scripts\build_bncc_okfs.py') --root $Root
$argsList = @((Join-Path $Root 'scripts\bootstrap_bncc_metis.py'), '--root', $Root)
if ($Wait) { $argsList += '--wait' }
& $python @argsList
