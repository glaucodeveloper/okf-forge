#!/usr/bin/env bash
set -euo pipefail
ROOT="${1:-$(cd "$(dirname "$0")" && pwd)}"
PYTHON="${OKFFORGE_PYTHON:-python3}"
"$PYTHON" "$ROOT/scripts/build_bncc_okfs.py" --root "$ROOT"
"$PYTHON" "$ROOT/scripts/bootstrap_bncc_metis.py" --root "$ROOT" --wait
