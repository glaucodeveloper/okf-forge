# OKF Forge — BNCC + Metis-4B

Pacote de integração da base Lumira/BNCC EF II com o OKF Forge.

## O que entra no pacote

- `okf_forge_bncc_app.nim` — aplicação GlaucoPlastic com navegação Matérias → Habilidades/Tópicos → Estudo com IA.
- `knowledge-studio-data/bncc/bncc_skill_manifest.json` — relação canônica entre matéria, habilidade, OKF e safetensor.
- `knowledge-studio-data/bncc/okf/<materia>/<codigo>.okf` — 730 OKFs, um por habilidade BNCC.
- `knowledge-studio-data/bncc/safetensors/<materia>/<codigo>.safetensors` — destino dos estados de memória Metis por habilidade.
- `scripts/build_bncc_okfs.py` — recompõe os 730 OKFs a partir das bases Lumira.
- `scripts/metis_skill_service.py` — mantém um Metis-4B carregado e troca o estado persistente por habilidade.
- `scripts/bootstrap_bncc_metis.py` — verifica todos os tensors ao iniciar e agenda geração dos ausentes/desatualizados.
- `scripts/verify_bncc_assets.py` — auditoria matéria → habilidade → OKF → tensor.
- `generate_bncc_tensors.ps1` / `.sh` — comandos prontos para reconstrução completa.

## Relação persistida

Cada entrada no manifesto possui:

```text
matter:<materia>
  HAS_TOPIC bncc:<codigo>
    HAS_OKF okf:bncc:<codigo>
      COMPILES_TO tensor:bncc:<codigo>
```

O `topic_key` é `<materia-slug>/<codigo>`. A UI usa esse vínculo; ela não descobre os arquivos por heurística.

## Fluxo na aplicação

1. A aplicação inicia em **Matérias BNCC**.
2. Um cartão de matéria abre a lista de habilidades daquela matéria.
3. Clicar em **Estudar com IA** define `ActiveSkillCode` e chama `/load` no serviço Metis.
4. `/load` verifica se o safetensor existe e se o `okf_sha256` ainda coincide com o OKF atual.
5. Se estiver ausente ou stale, o serviço faz `model.reset()`, commit do OKF no Metis e salva os estados locais no safetensor da habilidade.
6. O tensor é carregado nos `local_memory` dos blocos Metis.
7. Cada mensagem na tela de estudo gera uma resposta usando aquele OKF como escopo; o turno usuário+IA é commitado na memória e o mesmo safetensor é atualizado.
8. Abrir outra habilidade reseta a memória ativa e carrega o safetensor da nova habilidade.

## Inicialização automática

`okf_forge_bncc_app.nim` chama `bootstrap_bncc_metis.py` no startup. O script inicia o serviço local, se necessário, e agenda uma varredura dos 730 artefatos. A interface não precisa esperar a geração completa: abrir uma habilidade dá prioridade à geração/carregamento daquele tensor específico.

Para executar manualmente no Windows:

```powershell
./generate_bncc_tensors.ps1 -Wait
```

No Linux:

```bash
./generate_bncc_tensors.sh
```

A geração completa pode ocupar bastante disco porque cada habilidade recebe um estado de memória denso próprio. O pacote entregue contém os OKFs e os destinos; os tensors são produzidos localmente com o checkpoint configurado.

## Modelo Metis

Padrão:

```text
IAAR-Shanghai/Metis-4B
```

Variáveis aceitas, em ordem de prioridade:

```text
OKFFORGE_METIS_MODEL
GLAUCOPLASTIC_METIS_MODEL_PATH
GLAUCOPLASTIC_METIS_MODEL
GLAUCOPLASTIC_MODEL_PATH
```

Outras opções:

```text
OKFFORGE_ROOT
OKFFORGE_PYTHON
OKFFORGE_METIS_ENDPOINT=http://127.0.0.1:19193
OKFFORGE_METIS_HOST=127.0.0.1
OKFFORGE_METIS_PORT=19193
OKFFORGE_METIS_DEVICE=cuda:0
OKFFORGE_METIS_DTYPE=bfloat16
OKFFORGE_METIS_QUANTIZATION=4bit
```

O padrão `4bit` foi mantido para máquinas com VRAM limitada.

## Dependências Python

Instale o build de PyTorch compatível com sua CUDA e depois:

```bash
pip install -r requirements-metis.txt
```

## Verificação

Só OKFs:

```bash
python scripts/verify_bncc_assets.py --root .
```

Exigir os 730 safetensors válidos:

```bash
python scripts/verify_bncc_assets.py --root . --strict-tensors
```

## Atualização de um OKF

Se o arquivo `.okf` de uma habilidade mudar, o hash atual deixa de coincidir com o metadata do safetensor. O serviço marca o tensor como stale e o recompila no próximo `/load` ou no botão **Regerar do OKF**.

## Fonte pedagógica incluída

As bases Lumira usadas para gerar o catálogo estão em `data/lumira/`:

- `lumira_bncc_efii_habilidades_por_competencias.json`
- `lumira_bncc_efii_habilidades_competencias_eixos_v5.json`
- `lumira_efii_eixos_por_area_serie_idade_niveis_v5.json`
- `lumira_okf_efii_progressao_v5.yaml`
